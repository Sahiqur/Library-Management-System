import os
import time
from datetime import datetime


book_list = [
    {
    "title": "Book 1",
    "isbn": "1234567890",
    "publish_year": "2020",
    "author": ["Author 1", "Author 2"],
    "copies": 5,
    }
]
lent_list = []



def add_book():
    print("Include New Books")
    title = input("Enter Your Book Name and Title: ")
    isbn = input("Enter Your Book ISBN : ")
    publish_year = input("Enter Your Book Publish Year : ")
    author = input("Enter Book Author (You have to write using Comma) : ").split(",")
    copies = int(input("Enter your Book Quantity : "))


    if any(book["isbn"] == isbn for book in book_list):
        print("This Book already included, Please give the new one Book...!!!!")
        return

    new_book = {
        "title": title,
        "isbn": isbn,
        "publish_year": publish_year,
        "author": author,
        "copies": copies,
    }
    book_list.append(new_book)
    save_all_books()
    print("Your Book Included Succesfully..!!!")


def save_all_books():
    with open("book_list.csv", "w") as f:
        for book in book_list:
            f.write(
                f'{book["title"]} {book["isbn"]} {book["publish_year"]} {book["copies"]} {" ".join(book["author"])}\n'
            )


def load_books():
    if not os.path.exists("db/book_list.csv"):
        open("book_list.csv", "w").close()

    if os.path.getsize("book_list.csv") == 0:
        return

    with open("book_list.csv", "r") as f:
        for line in f:
            title, isbn, publish_year, copies, *authors = line.strip().split(" ")
            book_list.append(
                {
                    "title": title,
                    "isbn": isbn,
                    "publish_year": publish_year,
                    "author": authors,
                    "copies": int(copies),
                }
            )


def display_books(books):
    for book in books:
        print(
            f'Title: {book["title"]}, ISBN: {book["isbn"]}, Publish Year: {book["publish_year"]}, Author: {", ".join(book["author"])}, Copies: {book["copies"]}'
        )


def search_book():
    print("For Searching Your Book")
    search_term = input("Enter Book Title or ISBN for Searching : ")
    results = [
        book
        for book in book_list
        if search_term.lower() in book["title"].lower() or search_term in book["isbn"]
    ]
    if results:
        print("Search Results:")
        display_books(results)
    else:
        print("There has no book")


def search_by_author():
    print("Searching by Author")
    author_name = input("Enter Author Name: ")
    results = [
        book
        for book in book_list
        if author_name.lower() in [auth.lower() for auth in book["author"]]
    ]
    if results:
        print(f"Books by {author_name.capitalize()}:")
        display_books(results)
    else:
        print("There has no Book")


# Lent functions
def save_lent_book(book):
    if not os.path.exists("lent_book.csv"):
        open("lent_book.csv", "w").close()

    with open("lent_book.csv", "a") as f:
        f.write(
            f'{book["title"]} {book["isbn"]} {book["issue_date"]} {book["due_date"]} {book["name"]} {" ".join(book["author"])}\n'
        )


def load_lent_books():
    if not os.path.exists("lent_book.csv"):
        open("lent_book.csv", "w").close()

    if os.path.getsize("lent_book.csv") == 0:
        return

    with open("lent_book.csv", "r") as f:
        for line in f:
            title, isbn, issue_date, due_date, name, *authors = line.strip().split(" ")
            lent_list.append(
                {
                    "title": title,
                    "isbn": isbn,
                    "issue_date": issue_date,
                    "due_date": due_date,
                    "name": name,
                    "author": authors,
                }
            )
def update_lent_books():
    with open("lent_book.csv", "w") as f:
        for book in lent_list:
            f.write(
                f'{book["title"]} {book["isbn"]} {book["issue_date"]} {book["due_date"]} {book["name"]} {" ".join(book["author"])}\n'
            )


def lent_book():
    load_books()
    key = input("Enter book Name or ISBN number: ")
    for book in book_list:
        if key.lower() in book["title"].lower() or key.lower() in book["isbn"]:
            if book["copies"] > 0:
                print(f"This book is available")
                name = input("Enter Name: ")
                issue_date = datetime.now().strftime("%Y-%m-%d")
                due_date = input("Due Date (YYYY-MM-DD): ")
                lent_book = {
                    "title": book["title"],
                    "isbn": book["isbn"],
                    "issue_date": issue_date,
                    "due_date": due_date,
                    "name": name,
                    "author": book["author"],
                }
                lent_list.append(lent_book)
                book["copies"] -= 1
                save_all_books()
                save_lent_book(lent_book)
                break
            else:
                print(f'Sorry, {book["title"]} is not availabe.')
                break
    else:
        print("Book not found.")


def display_lent_books():
    for book in lent_list:
        print(
            f'{book["title"]} {book["isbn"]} {book["issue_date"]} {book["due_date"]} {book["name"]} {" ".join(book["author"])}'
        )


def return_book():
    load_lent_books()
    key = input("Enter book Name or ISBN number: ")
    for book in book_list:
        if key.lower() in book["title"].lower() or key.lower() in book["isbn"]:
            book["copies"] += 1
            save_all_books()

    for index, book in enumerate(lent_list):
        if key.lower() in book["title"].lower() or key.lower() in book["isbn"]:
            lent_list.pop(index)
            update_lent_books()
            break
    else:
        print("Book is not availabe")
        
def remove_book():
    search_term = input("Enter text to search to remove: ")
    for index, contact in enumerate(book_list):
        if search_term.lower() in contact["title"].lower():
            print(f"{index+1}. {contact['title']} - {contact['isbn']}- {contact['publish_year']}- {contact['author']}- {contact['copies']}")
            
    select_index=int(input("Enter The delete Item : "))
    book_list.pop(select_index-1)


def main_menu():
    while True:
        print("Welcome to Our Software")
        print("Library Management System")
        print("==========================")
        print("1. Add Book")
        print("2. View Books")
        print("3. Search Book")
        print("4. Search by Author")
        print("5. Lend Book")
        print("6. Display Lent Books")
        print("7. Return Book")
        print("8. Remove Book")
        print("0. Exit")

        choice = input("Enter your choice (1-8): ")
        if choice == "1":
            add_book()
        elif choice == "2":
            display_books(book_list)
        elif choice == "3":
            search_book()
        elif choice == "4":
            search_by_author()
        elif choice == "5":
            lent_book()
        elif choice == "6":
            display_lent_books()
        elif choice == "7":
            return_book()
        elif choice == "8":
            remove_book()
        elif choice == "0":
            print("Thank you for using the Library Management System.")
            break
        else:
            print("Invalid choice. Please try again.")
main_menu()

